#include "CondFormats/RunInfo/interface/RunNumber.h"
runinfo_test::RunNumber::RunNumber(){
  m_runnumber.reserve(600000);
}
