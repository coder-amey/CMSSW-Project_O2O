
#include "CondFormats/RunInfo/interface/L1TriggerScaler.h"
#include "FWCore/Utilities/interface/typelookup.h"


TYPELOOKUP_DATA_REG(L1TriggerScaler);
