#include "CondFormats/RunInfo/interface/RunSummary.h"
#include "FWCore/Utilities/interface/typelookup.h"

TYPELOOKUP_DATA_REG(RunSummary);
