#include "CondFormats/RunInfo/interface/RunNumber.h"
#include "FWCore/Utilities/interface/typelookup.h"

TYPELOOKUP_DATA_REG(runinfo_test::RunNumber);
