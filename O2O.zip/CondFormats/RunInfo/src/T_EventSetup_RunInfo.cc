#include "CondFormats/RunInfo/interface/RunInfo.h"
#include "FWCore/Utilities/interface/typelookup.h"

TYPELOOKUP_DATA_REG(RunInfo);
