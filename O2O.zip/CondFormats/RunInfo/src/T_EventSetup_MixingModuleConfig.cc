#include "CondFormats/RunInfo/interface/MixingModuleConfig.h"
#include "FWCore/Utilities/interface/typelookup.h"

TYPELOOKUP_DATA_REG(MixingModuleConfig);
