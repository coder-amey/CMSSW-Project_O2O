#include "CondFormats/Serialization/interface/Test.h"

#include "../src/headers.h"

int main()
{
    testSerialization<FillInfo>();
    testSerialization<L1TriggerScaler>();
    testSerialization<L1TriggerScaler::Lumi>();
    testSerialization<MixingInputConfig>();
    testSerialization<MixingModuleConfig>();
    testSerialization<RunInfo>();
    testSerialization<RunSummary>();
    testSerialization<runinfo_test::RunNumber>();
    testSerialization<runinfo_test::RunNumber::Item>();
    testSerialization<std::bitset<3565>>();
    testSerialization<std::vector<L1TriggerScaler::Lumi>>();
    testSerialization<std::vector<MixingInputConfig>>();
    testSerialization<std::vector<runinfo_test::RunNumber::Item>>();

    return 0;
}
