# CMSSW-Project_O2O

This is Project O2O's sandbox workspace repository of the RunInfo module of the CondTools package from CERN's CMMSW Framework.
